
<?php

$con = mysqli_connect("localhost", "root", "", "cargo");
if (session_status() == PHP_SESSION_NONE) {
    @session_start();
}
?>


