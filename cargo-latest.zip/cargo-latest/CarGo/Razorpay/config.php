<?php
$razor_api_key = "rzp_test_sz1myTXmGUdpNJ";
?>