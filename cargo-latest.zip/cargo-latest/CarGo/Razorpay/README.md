# how-to-integrate-razorpay-payment-gateway
How to integrate razorpay payment gateway using PHP tutorial  for beginners in phpexpertise.com

congig.php
Update your test keys.

charge.php
razorpay_payment_id - This is a reference id for that particular transaction. At the same time you can generate random id and give that ID to users for their reference but won't give ##razorpay_payment_id## to users.

After receiving response you can store these values in database based on status / status code.
