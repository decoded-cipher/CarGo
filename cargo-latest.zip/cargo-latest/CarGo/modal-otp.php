
      
        
        <!-- The Modal -->
        <div class="sframe">
        <div id="myModal" class="smodal">
            <form id="verifyform" method="post">
                <!-- Modal content -->
                <div class="smodal-content">
                    <span class="sclose">&times;</span>
                    <br>    

                    <div style="display: inline-block;text-align: center">
                        <img style="margin-left: 50px" src="assets/img/mobile.png" width="150px" height="150px">
                    </div>
                    <div style="text-align: center">
                        An OTP was sent to your mobile number.<br>Enter OTP to complete User Registration.
                        
                        <div class="extra">
                            <input type="text" placeholder="Enter OTP" id="otp_verify" name="otp_verify">
                        </div>                
                    </div>
                    <button class="mbutton" id="verifybtn">Verfiy OTP</button>
                    <small> Didn't receive OTP?
                        <a href="javascript:void(0);" id="resend_otp">Resend</a> OTP.
                    </small>
                </div>
            </form>
        </div>
        </div>

        