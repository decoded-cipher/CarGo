
        <?php
        require_once "model/db.php";
          session_destroy();
          header('location:login.php');
        ?>


